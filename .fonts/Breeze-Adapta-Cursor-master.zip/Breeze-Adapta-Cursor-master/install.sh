#!/bin/bash
sudo rm -rf /usr/share/icons/Breeze-Adapta;
sudo mkdir /usr/share/icons/Breeze-Adapta;
sudo mv * /usr/share/icons/Breeze-Adapta;
cd ..;
rm -rf Breeze-Adapta;
