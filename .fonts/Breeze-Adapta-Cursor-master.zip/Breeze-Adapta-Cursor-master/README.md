# Breeze-Adapta-Cursor
Popular Breeze Cursor modified for Adapta theme

# Preview

<p align="center">
<img src="https://s19.postimg.cc/oezw42p9f/image.png" width="200px" /> <img src="https://s19.postimg.cc/xms4krolv/image.png" width="200px" /> 
</p>

# Installation

``` 
git clone https://github.com/mustafaozhan/Breeze-Adapta.git && cd Breeze-Adapta && chmod +x install.sh && sh install.sh

```

# Thanks to

<a href="https://github.com/KDE/breeze/tree/master/cursors">breeze</a>

<a href="https://github.com/posquit0/dotfiles/tree/master/X/.icons/Breeze-Obsidian">Breeze-Obsidian</a>

<a href="https://github.com/keeferrourke/capitaine-cursors">capitaine-cursors</a>



This cursor theme modified version of given cursor themes
